<template>
  <div class="c-main">
    <the-header></the-header>
    <div class="c-main__body">
      <router-view></router-view>
    </div>
  </div>
</template>

<script src="./script.js"></script>

<style lang="scss" src="./style.scss"></style>
