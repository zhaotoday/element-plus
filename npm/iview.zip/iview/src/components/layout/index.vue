<template>
  <div>
    <the-sidebar ref="sidebar"></the-sidebar>
    <the-main></the-main>
  </div>
</template>

<script src="./script.js"></script>
