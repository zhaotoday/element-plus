<template>
  <div class="p-home">欢迎使用管理后台。</div>
</template>

<script>
import { Component, Vue } from "vue-property-decorator";

@Component
export default class extends Vue {}
</script>
