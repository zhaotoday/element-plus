<template>
  <div class="p-unauthorized">unauthorized</div>
</template>

<script>
import { Component, Vue } from "vue-property-decorator";

@Component
export default class extends Vue {}
</script>
