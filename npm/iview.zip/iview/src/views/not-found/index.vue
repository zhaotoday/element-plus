<template>
  <div class="p-not-found">not found</div>
</template>

<script>
import { Component, Vue } from "vue-property-decorator";

@Component
export default class extends Vue {}
</script>
