export default {
  path: "/",
  component: resolve => require(["@/views/home"], resolve)
};
