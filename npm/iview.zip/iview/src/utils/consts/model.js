export default {
  categories: "分类",
  wxUsers: "微信用户"
};
