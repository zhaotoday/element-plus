export default {
  products: 2,
  articles: 1
};
