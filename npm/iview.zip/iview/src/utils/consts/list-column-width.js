export default {
  Title: 250,
  Category: 160,
  CreatedAt: 150,
  User: 100
};
