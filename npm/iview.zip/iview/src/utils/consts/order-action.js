export default [
  {
    value: "ToPrev",
    label: "上移"
  },
  {
    value: "ToNext",
    label: "下移"
  }
];
