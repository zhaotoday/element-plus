import helpers from "@/utils/helpers";

export default helpers.keyMirror({
  RESET_STATE: null
});
