import createStore from "view-ui-admin/src/utils/create-store";
import Model from "@/models/admin/orders";

export default createStore({ Model });
