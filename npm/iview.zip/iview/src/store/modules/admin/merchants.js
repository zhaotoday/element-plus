import createStore from "view-ui-admin/src/utils/create-store";
import Model from "@/models/admin/merchants";

export default createStore({ Model });
