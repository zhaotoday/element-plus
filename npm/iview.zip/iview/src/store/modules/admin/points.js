import createStore from "view-ui-admin/src/utils/create-store";
import Model from "@/models/admin/points";

export default createStore({ Model });
