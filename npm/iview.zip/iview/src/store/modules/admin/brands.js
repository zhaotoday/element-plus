import createStore from "view-ui-admin/src/utils/create-store";
import Model from "@/models/admin/brands";

export default createStore({ Model });
