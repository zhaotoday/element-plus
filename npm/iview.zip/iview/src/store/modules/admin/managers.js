import createStore from "view-ui-admin/src/utils/create-store";
import Model from "@/models/admin/managers";

export default createStore({ Model });
