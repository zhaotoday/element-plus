import createStore from "view-ui-admin/src/utils/create-store";
import Model from "@/models/admin/coupons";

export default createStore({ Model });
