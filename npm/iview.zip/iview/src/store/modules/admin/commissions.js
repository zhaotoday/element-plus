import createStore from "view-ui-admin/src/utils/create-store";
import Model from "@/models/admin/commissions";

export default createStore({ Model });
