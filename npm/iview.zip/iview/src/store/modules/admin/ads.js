import createStore from "view-ui-admin/src/utils/create-store";
import Model from "@/models/admin/ads";

export default createStore({ Model });
