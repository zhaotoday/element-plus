import createStore from "view-ui-admin/src/utils/create-store";
import Model from "@/models/public/managers";

export default createStore({ Model });
