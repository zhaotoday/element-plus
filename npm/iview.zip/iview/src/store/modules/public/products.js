import createStore from "view-ui-admin/src/utils/create-store";
import Model from "@/models/public/products";

export default createStore({ Model });
