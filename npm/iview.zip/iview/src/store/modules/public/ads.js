import createStore from "view-ui-admin/src/utils/create-store";
import Model from "@/models/public/ads";

export default createStore({ Model });
